import React, { useState } from "react";
import UserList from "./UserList";
import ManagePrescriptionLeft from "./ManagePrescriptionLeft";
import ManagePrescriptionRight from "./ManagePrescriptionRight";
import MPFooter from "./ManagePrescriptionfooter"
import ToggleSwitch from "../../components/ToggleSwitch/ToggleSwitch";

interface ManagePrescriptionProps {
  addToCart: (item: any) => void;
  handleSelectAllPres: (items: any[], isChecked: boolean) => void;
  rightData: any;
  setCartCount: (count: number) => void;
  setRightData: (data: any) => void;
}

const ManagePrescription: React.FC<ManagePrescriptionProps> = ({
  addToCart,
  handleSelectAllPres,
  setCartCount,
  setRightData,
}) => {
  const [rightData, setRightDataState] = useState<{}>({});
  const [cartCount, setCartCountState] = useState(0);
  const [isCurrent, setIsCurrent] = useState(true); //  State moved here
const[Prescription,setPrescription]=useState<{}>({});
  return (
    <>
      <UserList />
      <div className="main-grid-container">
        <div className="left">
          <ToggleSwitch isCurrent={isCurrent} setIsCurrent={setIsCurrent} />
          <ManagePrescriptionLeft
          setPrescription={Prescription}
            addToCart={addToCart}
            isCurrent={isCurrent}
            setRightData={setRightDataState}
            setCartCount={setCartCountState}
            handleSelectAllPres={handleSelectAllPres}
          />
        </div>
        <div className="right">
          <ManagePrescriptionRight rightData={rightData} setRightData={setRightDataState}/>
        </div>
        <div className="footer">
          <MPFooter cartCount={cartCount} selectedPrescriptions={[Prescription]} />
        </div>
      </div>
    </>
  );
};

export default ManagePrescription;