import React, { Dispatch, SetStateAction, useEffect, useState } from "react";
import {
  Box,
  Grid,
  Checkbox,
  Card,
  CardContent,
  CardMedia,
  Typography,
} from "@mui/material";
import MPFooter from "./ManagePrescriptionfooter";

const API_URL =
  "https://dev.apigee.northwell.io/api/vivo/rxdetails/v1/getRxDetails";

interface Prescription {
  rxNum: string;
  medName: string;
  rxStatus: string;
  dosage: string;
  refillsRemain: string;
  supplyDays: string;
  autoFill: string;
  rxSig: string;
  checked: boolean;
}

interface ManagePrescriptionLeftProps {
  addToCart: (item: any) => void;
  handleSelectAllPres: (items: any[], isChecked: boolean) => void;
  isCurrent: boolean;
  setRightData: Dispatch<SetStateAction<{}>>;
  setCartCount: Dispatch<SetStateAction<number>>;
  setPrescription: Dispatch<SetStateAction<{}>>;
}

const ManagePrescriptionLeft: React.FC<ManagePrescriptionLeftProps> = ({
  isCurrent,
  setRightData,
  setCartCount,
  addToCart,
}) => {
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
  const [selectedPrescription, setSelectedPrescription] =
    useState<Prescription | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectAll, setSelectAll] = useState(false); // Track select all state // Function to Fetch Prescriptions Based on Toggle (Current or Past)

  const fetchPrescriptions = async () => {
    const filterType = isCurrent ? "current" : "past";
    console.log(`Fetching ${filterType} prescriptions...`);
    setLoading(true); // Start Loading
    setPrescriptions([]); // Clear previous data

    try {
      const response = await fetch(`${API_URL}?t=${new Date().getTime()}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          pharmId: "",
          patientId: "10110839",
          rxNum: "",
          fillId: "",
          rxFilter: filterType, // API determines Current/Past
          fillFilter: "",
        }),
      });

      if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
      const result = await response.json();
      console.log("API Response:", result);

      const extractedPrescriptions = result.map((item: any) => ({
        ...item.rx,
        checked: false, // Add `checked` for UI management
      }));

      setPrescriptions(extractedPrescriptions);
      if (extractedPrescriptions.length > 0)
        setSelectedPrescription(extractedPrescriptions[0]);
    } catch (error) {
      console.error("Error fetching prescriptions:", error);
      setPrescriptions([]);
    } finally {
      setLoading(false); // Stop Loading
    }
  }; // Fetch data when `isCurrent` changes

  useEffect(() => {
    fetchPrescriptions();
  }, [isCurrent]); // Update right panel and cart count

  useEffect(() => {
    setCartCount(prescriptions.filter((p) => p.checked).length);
    setRightData(selectedPrescription || {});
  }, [prescriptions, setCartCount, selectedPrescription]); // Handle selecting a single prescription

  const handleCardClick = (data: Prescription) => {
    setSelectedPrescription(data);
  }; // Handle checkbox selection for an individual prescription

  const handleCheckboxChange = (rxNum: string) => {
    const updatedPrescriptions = prescriptions.map((prescription) =>
      prescription.rxNum === rxNum
        ? { ...prescription, checked: !prescription.checked }
        : prescription
    );

    setPrescriptions(updatedPrescriptions);
    setSelectAll(updatedPrescriptions.every((p) => p.checked)); // Update select all state
  }; // Handle "Select All" checkbox

  const handleSelectAll = () => {
    const allSelected = !selectAll; // Toggle select all state
    const updatedPrescriptions = prescriptions.map((p) => ({
      ...p,
      checked: allSelected,
    }));

    setPrescriptions(updatedPrescriptions);
    setSelectAll(allSelected); // Update state
    setCartCount(allSelected ? updatedPrescriptions.length : 0);

    if (allSelected) {
      updatedPrescriptions.forEach((item) => addToCart(item)); // Add all items to cart
    }
  };

  return (
    <Box sx={{ padding: 2 }}>
           
      <Grid container alignItems="center">
               
        <Grid item xs={6}>
                   
          <Typography variant="h6">
                       
            {isCurrent ? "Current Prescriptions" : "Past Prescriptions"}       
             
          </Typography>
                 
        </Grid>
               
        <Grid item xs={6}>
                    <Checkbox checked={selectAll} onChange={handleSelectAll} /> 
                  Select All        
        </Grid>
             
      </Grid>
           
      {loading ? (
        <Typography>
          Loading {isCurrent ? "Current" : "Past"} Prescriptions...
        </Typography>
      ) : (

        
        <Box>
                   
          {prescriptions.length === 0 ? (
            <Typography>
              No {isCurrent ? "Current" : "Past"} Prescriptions Found
            </Typography>
          ) : (
            prescriptions.map((data) => (
              <Card
                key={data.rxNum}
                onClick={() => handleCardClick(data)}
                sx={{
                  marginBottom: 2,
                  cursor: "pointer",
                  backgroundColor:
                    selectedPrescription?.rxNum === data.rxNum
                      ? "#fff"
                      : "#f7f7f7",
                  border:
                    selectedPrescription?.rxNum === data.rxNum
                      ? "1px solid #5C0B8A"
                      : "1px solid #eee",
                }}
              >
                               
                <CardContent sx={{ display: "flex" }}>
                                   
                  <CardMedia
                    component="img"
                    sx={{
                      width: 50,
                      height: 50,
                      borderRadius: "50%",
                      marginRight: 2,
                    }}
                    image={`./../assets/hamburger/medication.png`} // Placeholder image
                    alt="Medication"
                  />
                                   
                  <Box sx={{ flex: 1 }}>
                                       
                    <Typography fontWeight={520}>{data.medName}</Typography>   
                                   
                    <Typography>Dosage: {data.dosage || "N/A"}</Typography>     
                                 
                    <Typography>
                      Refills Remaining: {data.refillsRemain || "N/A"}
                    </Typography>
                                       
                    <Typography>
                      Supply Days: {data.supplyDays || "N/A"}
                    </Typography>
                                       
                    <Typography>
                      Prescription Status: {data.rxStatus}
                    </Typography>
                                     
                  </Box>
                                   
                  <Checkbox
                    checked={data.checked}
                    onChange={() => handleCheckboxChange(data.rxNum)}
                  />
                                 
                </CardContent>
                             
              </Card>
            ))
          )}
                 
        </Box>
      )}
         
    </Box>
  );
};

export default ManagePrescriptionLeft;
