import { Card, CardMedia, Typography } from "@mui/material";
import React, { Dispatch, SetStateAction, useState, useEffect } from "react";
import { Box, Button } from "@mui/material";
import ModalPopup from "./../modals/Modal_Popup";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";

interface Prescription {
  rxNum: string;
  medName: string;
  rxStatus: string;
  dosage: string;
  refillsRemain: string;
  supplyDays: string;
  autoFill: string;
  rxSig: string;
  checked?: boolean;
  tab_short_desc?: string;
  details?: string;
  side_effect?: string;
  prescriber?: string;
  expirationDate?: string;
  copay?: string;
  refillDue?: string;
  assignedTo?: string;
}

interface ManagePrescriptionRightProps {
  rightData: Prescription | any; // Now receiving selected prescription
  setRightData: Dispatch<SetStateAction<{}>>;
}

const ManagePrescriptionRight: React.FC<ManagePrescriptionRightProps> = ({
  rightData,
}) => {
  const [medicalInfo, setMedicalInfo] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [selectedPrescription, setSelectedPrescription] =
    useState<Prescription | null>(null);

  useEffect(() => {
    if (rightData) {
      setSelectedPrescription(rightData); // Update when selection changes
    }
  }, [rightData]);

  if (!selectedPrescription) {
    return (
      <Box sx={{ padding: 3, textAlign: "center" }}>
        <Typography variant="h6">No Prescription Selected</Typography>
        <Typography>Select a prescription from the left panel.</Typography>
      </Box>
    );
  }

  const {
    medName,
    dosage,
    prescriber,
    supplyDays,
    rxNum,
    expirationDate,
    copay,
    refillDue,
    assignedTo,
    details,
    tab_short_desc,
    side_effect,
    rxSig,
  } = selectedPrescription;
  const fullText = rxSig || "No instructions available.";
  const truncatedText =
    fullText.length > 85 ? fullText.slice(0, 80) + "..." : fullText;

  return (
    <Box
      sx={{
        top: "0px",
        height: "calc(100vh - 250px)",
        overflowY: "scroll",
        scrollbarWidth: "thin",
        "&::-webkit-scrollbar": { width: "8px" },
        "&::-webkit-scrollbar-thumb": {
          backgroundColor: "#aaa",
          borderRadius: "4px",
        },
        "&::-webkit-scrollbar-thumb:hover": { backgroundColor: "#888" },
      }}
    >
      <Card>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            width: "100%",
            height: "100%",
            padding: "20px",
            backgroundColor: "#919191",
            borderBottomRightRadius: "20px",
            borderBottomLeftRadius: "20px",
          }}
        >
          <CardMedia
            component="img"
            sx={{ width: "300px", objectFit: "cover" }}
            image={`./../assets/hamburger/medication.png`} // Placeholder image
            alt="Medication"
          />
        </div>

        <Box sx={{ padding: 2 }}>
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Box sx={{ display: "flex", justifyContent: "start", gap: "5px" }}>
              <Typography
                sx={{ fontWeight: "520", fontSize: "20px", color: "#292929" }}
              >
                {medName}
              </Typography>
              <Typography sx={{ fontWeight: "520", fontSize: "20px" }}>
                {dosage || "N/A"}
              </Typography>
            </Box>
          </Box>

          <Typography sx={{ marginRight: "5px", marginTop: "12px" }}>
            {supplyDays} capsules • for {assignedTo || "N/A"}
          </Typography>
          <Typography>Refill due on: {refillDue || "N/A"}</Typography>
          <Typography>Last copay: {copay || "N/A"}</Typography>

          <Button
            variant="outlined"
            sx={{
              color: "#5C0B8A",
              border: "1px solid #5C0B8A",
              textTransform: "none",
              fontSize: "16px",
              fontWeight: "520",
              marginBottom: "12px",
              marginTop: "12px",
            }}
            fullWidth
            onClick={() => setMedicalInfo(true)}
          >
            Medication Information
          </Button>

          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 2,
              marginTop: "12px",
            }}
          >
            <Box sx={{ display: "flex", flexDirection: "column" }}>
              <Typography sx={{ fontWeight: "500", fontSize: "14px" }}>
                Prescriber
              </Typography>
              <Typography sx={{ fontWeight: "500", fontSize: "16px" }}>
                {prescriber || "N/A"}
              </Typography>
            </Box>

            <Box sx={{ display: "flex", flexDirection: "column" }}>
              <Typography sx={{ fontWeight: "500", fontSize: "14px" }}>
                Days' supply
              </Typography>
              <Typography sx={{ fontWeight: "500", fontSize: "16px" }}>
                {supplyDays || "N/A"}
              </Typography>
            </Box>

            <Box sx={{ display: "flex", flexDirection: "column" }}>
              <Typography sx={{ fontWeight: "500", fontSize: "14px" }}>
                Rx number
              </Typography>
              <Typography sx={{ fontWeight: "500", fontSize: "16px" }}>
                {rxNum || "N/A"}
              </Typography>
            </Box>

            <Box sx={{ display: "flex", flexDirection: "column" }}>
              <Typography sx={{ fontWeight: "500", fontSize: "14px" }}>
                Rx expiration date
              </Typography>
              <Typography sx={{ fontWeight: "500", fontSize: "16px" }}>
                {expirationDate || "N/A"}
              </Typography>
            </Box>
          </Box>

          <Box sx={{ marginTop: "16px", marginBottom: "16px" }}>
            <Typography sx={{ fontSize: "14px", fontWeight: "520" }}>
              Medication Instructions
            </Typography>
            <Typography sx={{ fontSize: "16px", fontWeight: "520" }}>
              {isExpanded ? fullText : truncatedText}{" "}
              {fullText.length > 80 && (
                <Button
                  variant="text"
                  color="primary"
                  onClick={() => setIsExpanded(!isExpanded)}
                  sx={{
                    textTransform: "none",
                    fontSize: "14px",
                    fontWeight: 520,
                    color: "purple",
                  }}
                >
                  {isExpanded ? "See less" : "See more"}
                </Button>
              )}
            </Typography>
          </Box>
        </Box>
      </Card>

      {/* Medication Info Modal */}
      <ModalPopup
        open={medicalInfo}
        onClose={() => setMedicalInfo(false)}
        title="Medication Information"
        showFooter={false}
      >
        <Typography sx={{ fontSize: "24px", fontWeight: 530 }}>
          {medName} {dosage}
        </Typography>
        <Typography
          sx={{ fontSize: "16px", fontWeight: 500, paddingBottom: "30px" }}
        >
          {tab_short_desc || "No description available."}
        </Typography>
        <Typography sx={{ fontSize: "18px", fontWeight: 520 }}>
          Details
        </Typography>
        <Typography
          sx={{ fontSize: "16px", fontWeight: 500, paddingBottom: "30px" }}
        >
          {details || "No details available."}
        </Typography>
        <Typography sx={{ fontSize: "18px", fontWeight: 520 }}>
          Side Effects
        </Typography>
        <Typography
          sx={{ fontSize: "16px", fontWeight: 500, paddingBottom: "30px" }}
        >
          {side_effect || "No side effects reported."}
        </Typography>
      </ModalPopup>
    </Box>
  );
};

export default ManagePrescriptionRight;