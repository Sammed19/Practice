import React, { useMemo } from "react";
import { Avatar, List, ListItem, ListItemText } from "@mui/material";
import ManagePrescriptionData from "./ManagePrescriptiondata.json";

const UserList: React.FC = () => {
  const userColors = useMemo(() => {
    const getRandomColor = () => {
      const letter = "0123456789ABCDEF";
      let color = "#";
      for (let i = 0; i < 6; i++) {
        color += letter[Math.floor(Math.random() * 16)];
      }
      return color;
    };

    return ManagePrescriptionData.prescriptions.map(() => getRandomColor());
  }, []);

  return (
    <>
      <List
        sx={{
          display: "flex",
          flexDirection: "row",
          paddingTop: "10px",
          paddingBottom: "10px",
        }}
      >
        <ListItem
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-start",
            width: "auto",
          }}
        >
          <img src="../../../public/assets/hamburger/All_Users.png" />
        </ListItem>
        {ManagePrescriptionData.prescriptions.map((user, index) => (
          <ListItem
            key={index}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "flex-start",
              width: "auto",
            }}
          >
            <Avatar
              style={{
                backgroundColor: userColors[index],
                marginRight: "8px",
              }}
            >
              {user.assignedTo.charAt(0)}
            </Avatar>
            <ListItemText primary={user.assignedTo} />
          </ListItem>
        ))}
      </List>
    </>
  );
};

export default UserList;
