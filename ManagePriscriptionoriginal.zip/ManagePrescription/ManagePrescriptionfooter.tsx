import React from "react";
import { Button, Box } from "@mui/material";
import { useNavigate } from "react-router-dom";

interface MPFooterProps {
  cartCount: number;
  selectedPrescriptions: any[]; // List of selected prescriptions
}

const MPFooter: React.FC<MPFooterProps> = ({
  cartCount,
  selectedPrescriptions,
}) => {
  const navigate = useNavigate();

  // ✅ Function to Handle Cart Navigation
  const handleCartNavigation = () => {
    console.log( " Selected Prescriptions:", selectedPrescriptions);

    if (selectedPrescriptions.length > 0) {
      navigate("/cart", { state: { prescriptions: selectedPrescriptions } });
    } else {
      alert("No prescriptions selected. Please select at least one item.");
    }
  };

  return (
    <Box
      sx={{
        bottom: 0,
        width: "100%",
        backgroundColor: "#fff",
        boxShadow: "0 -2px 5px rgba(0,0,0,0.1)",
        display: "flex",
        justifyContent: "flex-end",
        alignItems: "center",
        padding: "10px",
        zIndex: 1000,
        paddingBottom: "60px",
        height: "120px",
      }}
    >
      {cartCount > 0 && (
        <Button
          variant="contained"
          color="primary"
          sx={{
            marginRight: "15px",
            height: "45px",
            width: "42%",
            textTransform: "none",
            backgroundColor: "#5C0B8A",
          }}
          onClick={handleCartNavigation}
        >
          {cartCount > 0
            ? `(${cartCount} ${
                cartCount === 1 ? "Item" : "Items"
              }) Added to Cart`
            : "Added to Cart"}
        </Button>
      )}
    </Box>
  );
};

export default MPFooter;
